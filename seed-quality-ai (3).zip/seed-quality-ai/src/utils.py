"""
utils.py
Shared helper functions used across data_prep.py, train.py, evaluate.py, predict.py, app.py.

Contains:
- Config loading (YAML -> dict)
- Global seeding for reproducibility
- Standardized label-mapping helpers (seed_type + condition -> single class name)
- Small IO helpers with meaningful error messages
"""

import os
import json
import random
import yaml
import numpy as np
import torch


def load_config(config_path: str = "config.yaml") -> dict:
    """Load the project YAML config. Raises a clear error if missing/malformed."""
    if not os.path.exists(config_path):
        raise FileNotFoundError(
            f"[utils.load_config] Could not find config file at '{config_path}'. "
            f"Make sure you run scripts from the project root, or pass --config explicitly."
        )
    try:
        with open(config_path, "r") as f:
            cfg = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ValueError(f"[utils.load_config] Failed to parse '{config_path}': {e}")
    return cfg


def set_global_seed(seed: int = 42):
    """Set random seeds everywhere possible for reproducible experiments."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    # Deterministic-ish behaviour (small speed cost, acceptable for an academic project)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_device() -> torch.device:
    """Return CUDA device if available, else CPU. Never assumes a GPU exists."""
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def ensure_dir(path: str):
    """Create a directory if it doesn't already exist."""
    os.makedirs(path, exist_ok=True)


def save_json(obj, path: str):
    ensure_dir(os.path.dirname(path) if os.path.dirname(path) else ".")
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)


def load_json(path: str):
    if not os.path.exists(path):
        raise FileNotFoundError(f"[utils.load_json] Expected file not found: '{path}'.")
    with open(path, "r") as f:
        return json.load(f)


def standardized_class_name(seed_type: str, raw_label: str) -> str:
    """
    Build a standardized class name of the form '<seed_type>__<original_label>'.

    IMPORTANT: We deliberately keep the ORIGINAL dataset label text (lower-cased,
    whitespace->underscore) rather than renaming/inventing a new defect taxonomy.
    This satisfies the project requirement to preserve original dataset labels
    while still disambiguating identical condition names across different seed types
    (e.g. wheat 'broken' vs corn 'broken' are tracked as distinct classes because
    visual defect appearance differs by crop).
    """
    clean_seed = seed_type.strip().lower().replace(" ", "_")
    clean_label = raw_label.strip().lower().replace(" ", "_").replace("-", "_")
    return f"{clean_seed}__{clean_label}"


def split_standardized_class(class_name: str):
    """Inverse of standardized_class_name(). Returns (seed_type, raw_label)."""
    if "__" not in class_name:
        raise ValueError(
            f"[utils.split_standardized_class] '{class_name}' is not a standardized "
            f"class name of the form '<seed_type>__<label>'."
        )
    seed_type, raw_label = class_name.split("__", 1)
    return seed_type, raw_label


def is_healthy_class(class_name: str, healthy_keyword: str = "healthy") -> bool:
    """Determine whether a standardized class name represents the healthy condition."""
    _, raw_label = split_standardized_class(class_name)
    return healthy_keyword.lower() in raw_label.lower()
