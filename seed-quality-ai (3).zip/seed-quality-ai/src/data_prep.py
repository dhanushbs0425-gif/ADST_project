"""
data_prep.py
Dataset ingestion and preparation pipeline.

Expected raw layout (auto-detected):

    dataset/raw/<seed_type>/<original_class_label>/*.jpg

Example:
    dataset/raw/wheat/healthy/*.jpg
    dataset/raw/wheat/broken/*.jpg
    dataset/raw/corn/moldy/*.jpg

This script:
  1. Scans dataset/raw/ and auto-detects seed types + original class labels.
  2. Preserves original labels; builds a transparent standardized mapping
     (see utils.standardized_class_name) and saves it to models/label_map.json.
  3. Verifies every image opens correctly (removes/reports corrupted files).
  4. Detects duplicate and near-duplicate images (perceptual hashing) to prevent
     the exact same physical seed photo leaking across train/val/test.
  5. Copies cleaned, deduplicated images into dataset/processed/<standardized_class>/.
  6. Performs an 80/10/10 group-aware split (duplicates/near-duplicates are kept
     together in a single split) into dataset/train, dataset/validation, dataset/test.
  7. Writes a dataset statistics report to outputs/dataset_stats.json.

No dataset is fabricated. If dataset/raw/ is empty, the script exits with clear
manual-download instructions instead of inventing data.
"""

import os
import sys
import shutil
import argparse
from collections import defaultdict

import imagehash
from PIL import Image, UnidentifiedImageError
from tqdm import tqdm

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from utils import load_config, ensure_dir, save_json, standardized_class_name, set_global_seed

VALID_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}

MANUAL_DOWNLOAD_INSTRUCTIONS = """
No images were found under dataset/raw/.

This project does not fabricate data. To proceed, download a legitimate public
seed-image dataset and place it under dataset/raw/<seed_type>/<class_label>/*.jpg

Examples of public sources you can manually download (verify license/terms yourself
before use, and cite them in README.md 'Dataset' section):
  - Kaggle: "Wheat Seed Detection / Quality" datasets
  - Kaggle: "Corn/Maize Seed Quality" datasets
  - Kaggle: "Soybean Seed" datasets
  - Mendeley Data / Zenodo agricultural seed image datasets
  - University agricultural extension repositories with open-licensed images

After downloading, arrange the folders like this and re-run this script:

    dataset/raw/wheat/healthy/*.jpg
    dataset/raw/wheat/broken/*.jpg
    dataset/raw/wheat/discolored/*.jpg
    dataset/raw/corn/healthy/*.jpg
    dataset/raw/corn/moldy/*.jpg
    dataset/raw/soybean/healthy/*.jpg
    dataset/raw/soybean/insect_damaged/*.jpg
    ...

Folder names become the ORIGINAL class labels and are preserved as-is (only
lower-cased / underscored for filesystem safety). Nothing is renamed or reinterpreted.
"""


def scan_raw_dataset(raw_dir: str):
    """
    Walk dataset/raw/<seed_type>/<label>/ and return a dict:
        { standardized_class_name: [list of absolute image paths] }
    plus a label_map describing the seed_type/original_label -> standardized name.
    """
    if not os.path.isdir(raw_dir):
        raise FileNotFoundError(f"[data_prep] raw_dir '{raw_dir}' does not exist.")

    class_to_files = defaultdict(list)
    label_map = {}  # standardized_name -> {"seed_type":..., "original_label":...}

    seed_types = sorted(
        d for d in os.listdir(raw_dir) if os.path.isdir(os.path.join(raw_dir, d))
    )
    for seed_type in seed_types:
        seed_dir = os.path.join(raw_dir, seed_type)
        labels = sorted(
            d for d in os.listdir(seed_dir) if os.path.isdir(os.path.join(seed_dir, d))
        )
        for label in labels:
            label_dir = os.path.join(seed_dir, label)
            std_name = standardized_class_name(seed_type, label)
            label_map[std_name] = {"seed_type": seed_type, "original_label": label}
            for fname in os.listdir(label_dir):
                ext = os.path.splitext(fname)[1].lower()
                if ext in VALID_EXTS:
                    class_to_files[std_name].append(os.path.join(label_dir, fname))

    return class_to_files, label_map


def filter_corrupted(class_to_files: dict):
    """Open every image; drop files that fail to load. Returns (clean dict, corrupted count)."""
    clean = defaultdict(list)
    corrupted = 0
    for cls, paths in class_to_files.items():
        for p in tqdm(paths, desc=f"Checking {cls}", leave=False):
            try:
                with Image.open(p) as img:
                    img.verify()
                clean[cls].append(p)
            except (UnidentifiedImageError, OSError, ValueError):
                corrupted += 1
    return clean, corrupted


def compute_hashes(class_to_files: dict):
    """Compute a perceptual hash (phash) for every image, used for dedup + leakage prevention."""
    hashes = {}  # path -> imagehash object
    for cls, paths in class_to_files.items():
        for p in tqdm(paths, desc=f"Hashing {cls}", leave=False):
            try:
                with Image.open(p) as img:
                    hashes[p] = imagehash.phash(img.convert("RGB"))
            except Exception:
                # Already filtered for corruption, but guard anyway
                continue
    return hashes


def dedupe_within_class(paths, hashes, threshold=5):
    """
    Group images by near-duplicate identity (hamming distance <= threshold) within
    a single class. Returns:
      - kept: list of representative paths (one per duplicate group)
      - groups: list of lists (each inner list = all paths belonging to same physical seed)
    Groups (not just single images) are later split as a unit to prevent leakage.
    """
    groups = []
    assigned = set()
    for p in paths:
        if p in assigned or p not in hashes:
            continue
        group = [p]
        assigned.add(p)
        for q in paths:
            if q in assigned or q not in hashes:
                continue
            if hashes[p] - hashes[q] <= threshold:
                group.append(q)
                assigned.add(q)
        groups.append(group)
    kept = [g[0] for g in groups]
    return kept, groups


def build_processed_and_split(class_to_files, processed_dir, train_dir, val_dir, test_dir,
                               ratios, hash_threshold, seed):
    """
    Deduplicate, copy cleaned images into dataset/processed/<class>/, then perform
    a duplicate-group-aware 80/10/10 split into train/validation/test so that
    near-duplicate images of the same physical seed never cross split boundaries.
    """
    import random
    rng = random.Random(seed)

    ensure_dir(processed_dir)
    for d in (train_dir, val_dir, test_dir):
        ensure_dir(d)

    stats = {"classes": {}, "total_raw": 0, "total_after_dedupe": 0, "duplicates_removed": 0}

    for cls, paths in class_to_files.items():
        stats["total_raw"] += len(paths)
        hashes = {}
        for p in paths:
            try:
                with Image.open(p) as img:
                    hashes[p] = imagehash.phash(img.convert("RGB"))
            except Exception:
                continue

        _, groups = dedupe_within_class(paths, hashes, threshold=hash_threshold)
        rng.shuffle(groups)

        n_groups = len(groups)
        n_train = max(1, int(round(n_groups * ratios["train"])))
        n_val = max(1 if n_groups > 1 else 0, int(round(n_groups * ratios["val"])))
        n_test = n_groups - n_train - n_val
        if n_test < 0:
            n_test = 0
            n_train = n_groups - n_val

        split_assignment = (["train"] * n_train) + (["validation"] * n_val) + (["test"] * n_test)
        split_assignment = split_assignment[:n_groups]
        while len(split_assignment) < n_groups:
            split_assignment.append("train")

        n_after_dedupe = 0
        n_dupes = 0
        for group, split_name in zip(groups, split_assignment):
            target_root = {"train": train_dir, "validation": val_dir, "test": test_dir}[split_name]
            target_class_dir = os.path.join(target_root, cls)
            processed_class_dir = os.path.join(processed_dir, cls)
            ensure_dir(target_class_dir)
            ensure_dir(processed_class_dir)

            n_dupes += len(group) - 1
            for i, src_path in enumerate(group):
                fname = f"{cls}_{os.path.basename(src_path)}"
                shutil.copy2(src_path, os.path.join(processed_class_dir, fname))
                # Only the FIRST image of a duplicate group is used for train/val/test
                # to avoid near-identical images inflating a split; extra near-dupes
                # remain available in processed/ for reference/statistics only.
                if i == 0:
                    shutil.copy2(src_path, os.path.join(target_class_dir, fname))
                    n_after_dedupe += 1

        stats["classes"][cls] = {
            "raw_count": len(paths),
            "duplicate_groups": n_groups,
            "used_after_dedupe": n_after_dedupe,
            "duplicates_removed": n_dupes,
            "train": split_assignment.count("train"),
            "validation": split_assignment.count("validation"),
            "test": split_assignment.count("test"),
        }
        stats["total_after_dedupe"] += n_after_dedupe
        stats["duplicates_removed"] += n_dupes

    return stats


def main():
    parser = argparse.ArgumentParser(description="Seed dataset ingestion & preparation pipeline")
    parser.add_argument("--config", default="config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    set_global_seed(cfg["project"]["seed"])
    paths_cfg = cfg["paths"]
    split_cfg = cfg["split"]

    raw_dir = paths_cfg["raw_dir"]

    print(f"[data_prep] Scanning raw dataset at '{raw_dir}' ...")
    class_to_files, label_map = scan_raw_dataset(raw_dir)

    total_found = sum(len(v) for v in class_to_files.values())
    if total_found == 0:
        print(MANUAL_DOWNLOAD_INSTRUCTIONS)
        sys.exit(1)

    print(f"[data_prep] Found {total_found} raw images across {len(class_to_files)} classes.")
    print("[data_prep] Verifying image integrity (removing corrupted files) ...")
    clean_files, n_corrupted = filter_corrupted(class_to_files)
    print(f"[data_prep] Removed {n_corrupted} corrupted images.")

    print("[data_prep] Deduplicating and building leakage-safe train/val/test split ...")
    ratios = {"train": split_cfg["train_ratio"], "val": split_cfg["val_ratio"], "test": split_cfg["test_ratio"]}
    stats = build_processed_and_split(
        clean_files,
        processed_dir=paths_cfg["processed_dir"],
        train_dir=paths_cfg["train_dir"],
        val_dir=paths_cfg["val_dir"],
        test_dir=paths_cfg["test_dir"],
        ratios=ratios,
        hash_threshold=split_cfg["dedupe_hash_threshold"],
        seed=cfg["project"]["seed"],
    )
    stats["corrupted_removed"] = n_corrupted

    ensure_dir(os.path.dirname(paths_cfg["label_map_path"]))
    save_json(label_map, paths_cfg["label_map_path"])
    save_json(stats, paths_cfg["stats_report_path"])

    print(f"[data_prep] Label map saved to {paths_cfg['label_map_path']}")
    print(f"[data_prep] Dataset statistics saved to {paths_cfg['stats_report_path']}")
    print("[data_prep] Done. Class summary:")
    for cls, s in stats["classes"].items():
        print(f"  - {cls}: raw={s['raw_count']} used={s['used_after_dedupe']} "
              f"train={s['train']} val={s['validation']} test={s['test']}")


if __name__ == "__main__":
    main()
