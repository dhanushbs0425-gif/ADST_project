"""
evaluate.py
Evaluates the trained model on the held-out dataset/test split (never seen during
training or model selection) and exports the model to ONNX format.

Usage:
    python src/evaluate.py --config config.yaml

Outputs:
    outputs/confusion_matrix.png
    outputs/classification_report.txt
    models/best_model.onnx
"""

import os
import sys
import argparse

import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from sklearn.metrics import (
    confusion_matrix, classification_report, accuracy_score,
    precision_recall_fscore_support
)
import matplotlib.pyplot as plt
import seaborn as sns

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from utils import load_config, get_device, ensure_dir, load_json
from train import build_model, build_transforms


def load_trained_model(cfg, device):
    paths = cfg["paths"]
    if not os.path.exists(paths["best_model_path"]):
        raise FileNotFoundError(
            f"[evaluate] No trained model found at '{paths['best_model_path']}'. "
            f"Run 'python src/train.py' first."
        )
    checkpoint = torch.load(paths["best_model_path"], map_location=device)
    class_names = checkpoint["class_names"]

    # pretrained=False: we're about to load a fully trained state_dict anyway, so
    # skip downloading ImageNet weights here (avoids an unnecessary network dependency).
    model = build_model(len(class_names), cfg, use_pretrained_weights=False)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.to(device)
    model.eval()
    return model, class_names, checkpoint


def evaluate_on_test(model, class_names, cfg, device):
    paths = cfg["paths"]
    if not os.path.isdir(paths["test_dir"]) or len(os.listdir(paths["test_dir"])) == 0:
        raise FileNotFoundError(
            f"[evaluate] Test directory '{paths['test_dir']}' is missing or empty. "
            f"Run 'python src/data_prep.py' first."
        )

    _, eval_tf = build_transforms(cfg)
    test_ds = datasets.ImageFolder(paths["test_dir"], transform=eval_tf)

    if test_ds.classes != class_names:
        raise ValueError(
            f"[evaluate] Test set classes {test_ds.classes} do not match the "
            f"model's class_names {class_names}. The model and dataset are out of sync."
        )

    test_loader = DataLoader(test_ds, batch_size=cfg["train"]["batch_size"], shuffle=False,
                              num_workers=cfg["train"]["num_workers"])

    all_preds, all_labels = [], []
    with torch.no_grad():
        for images, labels in test_loader:
            images = images.to(device)
            outputs = model(images)
            preds = torch.argmax(outputs, dim=1).cpu().numpy()
            all_preds.extend(preds.tolist())
            all_labels.extend(labels.numpy().tolist())

    return np.array(all_labels), np.array(all_preds)


def generate_reports(y_true, y_pred, class_names, outputs_dir):
    ensure_dir(outputs_dir)

    acc = accuracy_score(y_true, y_pred)
    macro_f1 = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)[2]
    weighted_f1 = precision_recall_fscore_support(y_true, y_pred, average="weighted", zero_division=0)[2]

    report_text = classification_report(y_true, y_pred, target_names=class_names, zero_division=0)
    header = (
        f"Overall Accuracy : {acc:.4f}\n"
        f"Macro F1-score   : {macro_f1:.4f}\n"
        f"Weighted F1-score: {weighted_f1:.4f}\n"
        f"{'-'*60}\n"
        f"Per-class report (precision / recall / f1-score / support):\n\n"
    )
    full_report = header + report_text

    report_path = os.path.join(outputs_dir, "classification_report.txt")
    with open(report_path, "w") as f:
        f.write(full_report)
    print(full_report)
    print(f"[evaluate] Classification report saved to {report_path}")

    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(max(8, len(class_names) * 0.6), max(6, len(class_names) * 0.5)))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Greens",
                xticklabels=class_names, yticklabels=class_names)
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.title("Confusion Matrix (Test Set)")
    plt.xticks(rotation=45, ha="right")
    plt.yticks(rotation=0)
    plt.tight_layout()
    cm_path = os.path.join(outputs_dir, "confusion_matrix.png")
    plt.savefig(cm_path, dpi=150)
    plt.close()
    print(f"[evaluate] Confusion matrix saved to {cm_path}")

    return {"accuracy": acc, "macro_f1": macro_f1, "weighted_f1": weighted_f1}


def export_to_onnx(model, class_names, cfg, device):
    """Export the trained model to ONNX and verify it produces sane output."""
    import onnx
    import onnxruntime as ort

    img_size = cfg["image"]["image_size"]
    onnx_path = cfg["paths"]["onnx_model_path"]
    ensure_dir(os.path.dirname(onnx_path))

    dummy_input = torch.randn(1, 3, img_size, img_size, device=device)
    model.eval()
    # dynamo=False forces the classic TorchScript-based exporter, which avoids an
    # optional 'onnxscript' dependency required only by PyTorch's newer dynamo exporter.
    export_kwargs = dict(
        input_names=["input"], output_names=["logits"],
        dynamic_axes={"input": {0: "batch_size"}, "logits": {0: "batch_size"}},
        opset_version=13,
    )
    try:
        torch.onnx.export(model, dummy_input, onnx_path, dynamo=False, **export_kwargs)
    except TypeError:
        # Older torch versions don't have the 'dynamo' argument at all (legacy exporter only)
        torch.onnx.export(model, dummy_input, onnx_path, **export_kwargs)
    print(f"[evaluate] ONNX model exported to {onnx_path}")

    # Structural check
    onnx_model = onnx.load(onnx_path)
    onnx.checker.check_model(onnx_model)

    # Functional check: compare PyTorch vs ONNXRuntime outputs on the same input
    with torch.no_grad():
        torch_out = model(dummy_input).cpu().numpy()

    sess = ort.InferenceSession(onnx_path, providers=["CPUExecutionProvider"])
    ort_out = sess.run(None, {"input": dummy_input.cpu().numpy()})[0]

    max_diff = float(np.max(np.abs(torch_out - ort_out)))
    print(f"[evaluate] ONNX verification: max abs diff vs PyTorch output = {max_diff:.6f}")
    if max_diff > 1e-3:
        print("[evaluate] WARNING: ONNX output diverges from PyTorch output more than expected.")
    else:
        print("[evaluate] ONNX model verified successfully (outputs match PyTorch).")


def main():
    parser = argparse.ArgumentParser(description="Evaluate seed quality classifier on test set")
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--skip-onnx", action="store_true", help="Skip ONNX export/verification step")
    args = parser.parse_args()

    cfg = load_config(args.config)
    device = get_device()
    print(f"[evaluate] Using device: {device}")

    model, class_names, checkpoint = load_trained_model(cfg, device)
    print(f"[evaluate] Loaded checkpoint from epoch {checkpoint.get('epoch', '?')}")

    y_true, y_pred = evaluate_on_test(model, class_names, cfg, device)
    metrics = generate_reports(y_true, y_pred, class_names, cfg["paths"]["outputs_dir"])

    if not args.skip_onnx:
        export_to_onnx(model, class_names, cfg, device)

    print("[evaluate] Final test metrics:", metrics)


if __name__ == "__main__":
    main()
