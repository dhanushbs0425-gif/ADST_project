"""
train.py
Trains a MobileNetV2 transfer-learning classifier on dataset/train and
dataset/validation, printing per-epoch metrics and saving the best checkpoint.

Usage:
    python src/train.py --config config.yaml

Outputs:
    models/best_model.pt         (state_dict + metadata)
    models/class_names.json      (index -> standardized class name, ordered)
    models/config.json           (snapshot of the config used for this run)
    outputs/training_curves.png
"""

import os
import sys
import time
import argparse

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms, models
from sklearn.metrics import precision_recall_fscore_support, accuracy_score
import matplotlib.pyplot as plt

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from utils import load_config, set_global_seed, get_device, ensure_dir, save_json


def build_transforms(cfg):
    img_size = cfg["image"]["image_size"]
    mean, std = cfg["image"]["mean"], cfg["image"]["std"]
    aug = cfg["augmentation"]

    train_tf = transforms.Compose([
        transforms.RandomResizedCrop(img_size, scale=tuple(aug["random_resized_crop_scale"])),
        transforms.RandomHorizontalFlip(p=aug["horizontal_flip_prob"]),
        transforms.RandomVerticalFlip(p=aug["vertical_flip_prob"]),
        transforms.RandomRotation(aug["random_rotation_degrees"]),
        transforms.RandomAffine(
            degrees=aug["affine_degrees"],
            translate=tuple(aug["affine_translate"]),
        ),
        transforms.ColorJitter(
            brightness=aug["color_jitter"]["brightness"],
            contrast=aug["color_jitter"]["contrast"],
            saturation=aug["color_jitter"]["saturation"],
            hue=aug["color_jitter"]["hue"],
        ),
        transforms.ToTensor(),
        transforms.Normalize(mean=mean, std=std),
    ])

    eval_tf = transforms.Compose([
        transforms.Resize((img_size, img_size)),
        transforms.ToTensor(),
        transforms.Normalize(mean=mean, std=std),
    ])
    return train_tf, eval_tf


def build_model(num_classes: int, cfg, use_pretrained_weights: bool = None):
    """
    MobileNetV2 with a replaced classifier head.

    use_pretrained_weights controls whether ImageNet weights are downloaded:
      - During TRAINING this should be True (cfg["model"]["pretrained"]) so the
        backbone starts from useful features.
      - During INFERENCE (evaluate.py / predict.py) this should be False, since a
        full trained state_dict is loaded right after construction anyway and
        downloading ImageNet weights would be a wasted network dependency.
    If not explicitly passed, falls back to cfg["model"]["pretrained"].
    """
    if use_pretrained_weights is None:
        use_pretrained_weights = cfg["model"]["pretrained"]
    weights = models.MobileNet_V2_Weights.IMAGENET1K_V1 if use_pretrained_weights else None
    model = models.mobilenet_v2(weights=weights)

    in_features = model.classifier[1].in_features
    model.classifier = nn.Sequential(
        nn.Dropout(p=cfg["model"]["dropout"]),
        nn.Linear(in_features, num_classes),
    )
    return model


def set_backbone_trainable(model, trainable: bool):
    for param in model.features.parameters():
        param.requires_grad = trainable


def run_epoch(model, loader, criterion, optimizer, device, train_mode: bool):
    model.train() if train_mode else model.eval()
    total_loss = 0.0
    all_preds, all_labels = [], []

    torch.set_grad_enabled(train_mode)
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        if train_mode:
            optimizer.zero_grad()

        outputs = model(images)
        loss = criterion(outputs, labels)

        if train_mode:
            loss.backward()
            optimizer.step()

        total_loss += loss.item() * images.size(0)
        preds = torch.argmax(outputs, dim=1)
        all_preds.extend(preds.cpu().numpy().tolist())
        all_labels.extend(labels.cpu().numpy().tolist())

    avg_loss = total_loss / len(loader.dataset)
    acc = accuracy_score(all_labels, all_preds)
    precision, recall, f1, _ = precision_recall_fscore_support(
        all_labels, all_preds, average="macro", zero_division=0
    )
    return avg_loss, acc, precision, recall, f1


def main():
    parser = argparse.ArgumentParser(description="Train seed quality classifier (MobileNetV2)")
    parser.add_argument("--config", default="config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    set_global_seed(cfg["project"]["seed"])
    device = get_device()
    print(f"[train] Using device: {device}")

    paths = cfg["paths"]
    for split_name, split_dir in [("train", paths["train_dir"]), ("validation", paths["val_dir"])]:
        if not os.path.isdir(split_dir) or len(os.listdir(split_dir)) == 0:
            raise FileNotFoundError(
                f"[train] '{split_dir}' is missing or empty. Run 'python src/data_prep.py' first "
                f"to populate {split_name} data from dataset/raw/."
            )

    train_tf, eval_tf = build_transforms(cfg)
    train_ds = datasets.ImageFolder(paths["train_dir"], transform=train_tf)
    val_ds = datasets.ImageFolder(paths["val_dir"], transform=eval_tf)

    # Guard: class folders must match between train and val (data_prep guarantees this normally)
    if train_ds.classes != val_ds.classes:
        raise ValueError(
            "[train] Mismatch between train and validation class folders: "
            f"{train_ds.classes} vs {val_ds.classes}. Re-run data_prep.py."
        )
    class_names = train_ds.classes
    num_classes = len(class_names)
    print(f"[train] Detected {num_classes} classes: {class_names}")

    train_loader = DataLoader(train_ds, batch_size=cfg["train"]["batch_size"], shuffle=True,
                               num_workers=cfg["train"]["num_workers"], pin_memory=torch.cuda.is_available())
    val_loader = DataLoader(val_ds, batch_size=cfg["train"]["batch_size"], shuffle=False,
                             num_workers=cfg["train"]["num_workers"], pin_memory=torch.cuda.is_available())

    model = build_model(num_classes, cfg).to(device)
    criterion = nn.CrossEntropyLoss()

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg["train"]["learning_rate"],
        weight_decay=cfg["train"]["weight_decay"],
    )

    epochs = cfg["train"]["epochs"]
    if cfg["train"]["scheduler"] == "cosine":
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    else:
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", patience=2)

    ensure_dir(paths["models_dir"])
    ensure_dir(paths["outputs_dir"])

    best_metric = -1.0
    best_epoch = -1
    patience_counter = 0
    history = {"train_loss": [], "val_loss": [], "train_acc": [], "val_acc": [],
               "precision": [], "recall": [], "f1": [], "lr": []}

    freeze_epochs = cfg["model"]["freeze_backbone_epochs"]

    for epoch in range(1, epochs + 1):
        set_backbone_trainable(model, trainable=(epoch > freeze_epochs))

        t0 = time.time()
        train_loss, train_acc, _, _, _ = run_epoch(model, train_loader, criterion, optimizer, device, True)
        val_loss, val_acc, val_prec, val_rec, val_f1 = run_epoch(model, val_loader, criterion, optimizer, device, False)

        if cfg["train"]["scheduler"] == "cosine":
            scheduler.step()
        else:
            scheduler.step(val_loss)
        current_lr = optimizer.param_groups[0]["lr"]

        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["train_acc"].append(train_acc)
        history["val_acc"].append(val_acc)
        history["precision"].append(val_prec)
        history["recall"].append(val_rec)
        history["f1"].append(val_f1)
        history["lr"].append(current_lr)

        elapsed = time.time() - t0
        print(f"[Epoch {epoch:02d}/{epochs}] "
              f"train_loss={train_loss:.4f} val_loss={val_loss:.4f} "
              f"train_acc={train_acc:.4f} val_acc={val_acc:.4f} "
              f"precision={val_prec:.4f} recall={val_rec:.4f} f1={val_f1:.4f} "
              f"lr={current_lr:.6f} ({elapsed:.1f}s)")

        monitor_value = val_f1 if cfg["train"]["monitor_metric"] == "val_f1" else -val_loss
        if monitor_value > best_metric:
            best_metric = monitor_value
            best_epoch = epoch
            patience_counter = 0
            torch.save({
                "model_state_dict": model.state_dict(),
                "class_names": class_names,
                "num_classes": num_classes,
                "epoch": epoch,
                "val_f1": val_f1,
                "val_loss": val_loss,
                "val_acc": val_acc,
            }, paths["best_model_path"])
            print(f"  -> New best model saved (epoch {epoch}, val_f1={val_f1:.4f})")
        else:
            patience_counter += 1
            if patience_counter >= cfg["train"]["early_stopping_patience"]:
                print(f"[train] Early stopping triggered at epoch {epoch} "
                      f"(no improvement for {patience_counter} epochs).")
                break

    save_json(class_names, paths["class_names_path"])
    save_json(cfg, paths["config_snapshot_path"])
    save_json(history, os.path.join(paths["outputs_dir"], "training_history.json"))

    # Training curves
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    axes[0].plot(history["train_loss"], label="Train Loss")
    axes[0].plot(history["val_loss"], label="Val Loss")
    axes[0].set_title("Loss"); axes[0].set_xlabel("Epoch"); axes[0].legend()

    axes[1].plot(history["train_acc"], label="Train Acc")
    axes[1].plot(history["val_acc"], label="Val Acc")
    axes[1].set_title("Accuracy"); axes[1].set_xlabel("Epoch"); axes[1].legend()

    axes[2].plot(history["f1"], label="Val Macro F1")
    axes[2].plot(history["precision"], label="Val Precision")
    axes[2].plot(history["recall"], label="Val Recall")
    axes[2].set_title("Validation Metrics"); axes[2].set_xlabel("Epoch"); axes[2].legend()

    fig.tight_layout()
    fig.savefig(os.path.join(paths["outputs_dir"], "training_curves.png"), dpi=150)
    print(f"[train] Training curves saved to {paths['outputs_dir']}/training_curves.png")

    print(f"[train] Best model: epoch {best_epoch}, val_f1={best_metric:.4f}")
    print(f"[train] Checkpoint: {paths['best_model_path']}")
    print(f"[train] Class names: {paths['class_names_path']}")


if __name__ == "__main__":
    main()
