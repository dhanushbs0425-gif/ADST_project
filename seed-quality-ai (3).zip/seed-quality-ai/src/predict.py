"""
predict.py
End-to-end single-image inference used by both the CLI and app.py (Gradio UI).

Given a seed image, returns:
    - seed_type            (e.g. "wheat")
    - condition             (original dataset label, e.g. "healthy", "moldy")
    - is_healthy            (bool)
    - confidence             (softmax probability of predicted class)
    - quality_score          (0-100 AI-derived visual score, NOT a lab measurement)
    - all_class_probabilities
    - gradcam_heatmap_overlay (PIL.Image) - visual explainability
    - recommendation          (plain-language, non-diagnostic guidance text)

Grad-CAM is implemented from scratch (forward/backward hooks) so the project has
no hard dependency on an external Grad-CAM library beyond what's in requirements.txt.
"""

import os
import sys
import argparse
import json

import numpy as np
import cv2
import torch
import torch.nn.functional as F
from PIL import Image

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from utils import load_config, get_device, load_json, split_standardized_class, is_healthy_class
from train import build_model, build_transforms


# -----------------------------------------------------------------------------
# Grad-CAM (custom, dependency-light implementation)
# -----------------------------------------------------------------------------
class GradCAM:
    """
    Minimal Grad-CAM implementation.
    Hooks the target convolutional layer, captures activations on forward pass
    and gradients on backward pass, then computes a class-discriminative heatmap.
    """

    def __init__(self, model: torch.nn.Module, target_layer_name: str):
        self.model = model
        self.activations = None
        self.gradients = None
        target_layer = self._resolve_layer(model, target_layer_name)
        target_layer.register_forward_hook(self._save_activation)
        target_layer.register_full_backward_hook(self._save_gradient)

    @staticmethod
    def _resolve_layer(model, dotted_name: str):
        module = model
        for part in dotted_name.split("."):
            module = module[int(part)] if part.isdigit() else getattr(module, part)
        return module

    def _save_activation(self, module, inp, out):
        self.activations = out.detach()

    def _save_gradient(self, module, grad_in, grad_out):
        self.gradients = grad_out[0].detach()

    def generate(self, input_tensor: torch.Tensor, class_idx: int):
        self.model.zero_grad()
        output = self.model(input_tensor)
        score = output[0, class_idx]
        score.backward()

        # Global-average-pool the gradients -> per-channel importance weights
        weights = self.gradients.mean(dim=(2, 3), keepdim=True)
        cam = (weights * self.activations).sum(dim=1, keepdim=True)
        cam = F.relu(cam)
        cam = F.interpolate(cam, size=input_tensor.shape[2:], mode="bilinear", align_corners=False)
        cam = cam.squeeze().cpu().numpy()
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return cam, output


def overlay_heatmap(original_pil: Image.Image, cam: np.ndarray, alpha: float = 0.45) -> Image.Image:
    """Blend a normalized Grad-CAM heatmap (0-1, HxW) onto the original image."""
    original = np.array(original_pil.convert("RGB").resize((cam.shape[1], cam.shape[0])))
    heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
    overlay = np.uint8(original * (1 - alpha) + heatmap * alpha)
    return Image.fromarray(overlay)


# -----------------------------------------------------------------------------
# Quality scoring & recommendations
# -----------------------------------------------------------------------------
def compute_quality_score(probs: dict, predicted_class: str, healthy_keyword: str) -> float:
    """
    Quality Score (0-100), AI-derived from visual model confidence only.

    - If the predicted class is 'healthy', score = healthy_probability * 100.
    - If defective, score is reduced proportionally to the defect's predicted
      probability: score = (1 - defect_probability) * 100, floored at 1.

    This is NOT an official seed purity / germination / laboratory quality
    measurement -- see README/App disclaimers.
    """
    if is_healthy_class(predicted_class, healthy_keyword):
        return round(probs[predicted_class] * 100, 1)
    else:
        defect_prob = probs[predicted_class]
        score = max(1.0, (1 - defect_prob) * 100)
        return round(score, 1)


RECOMMENDATION_TEMPLATES = {
    "healthy": "Seed appears visually healthy. It may be considered for further agricultural quality testing.",
    "broken": "Physical damage detected. Consider separating this seed from the planting batch.",
    "discolored": "Abnormal discoloration detected. Further inspection is recommended.",
    "discoloured": "Abnormal discoloration detected. Further inspection is recommended.",
    "moldy": "Possible mold-related visual defect detected. Separate the seed and perform appropriate agricultural/laboratory inspection.",
    "mold": "Possible mold-related visual defect detected. Separate the seed and perform appropriate agricultural/laboratory inspection.",
    "spotted": "Surface spotting detected. This may indicate fungal activity or physical blemish; inspection is recommended.",
    "insect_damaged": "Signs consistent with insect damage detected. Recommend segregating and inspecting the batch for infestation.",
    "cracked": "Cracking detected on the seed coat. This may affect viability; consider separating from the planting batch.",
    "shrivelled": "Shrivelling detected, which can indicate immaturity or poor fill. Further inspection is recommended.",
    "shriveled": "Shrivelling detected, which can indicate immaturity or poor fill. Further inspection is recommended.",
    "immature": "Signs of immaturity detected. Germination performance may be affected; further testing is recommended.",
}
DEFAULT_RECOMMENDATION = (
    "A visual defect was detected. Further agricultural/laboratory inspection is recommended "
    "before this seed is used for planting or included in a certified batch."
)


def get_recommendation(condition_label: str) -> str:
    key = condition_label.strip().lower().replace(" ", "_")
    return RECOMMENDATION_TEMPLATES.get(key, DEFAULT_RECOMMENDATION)


# -----------------------------------------------------------------------------
# Main inference entry point
# -----------------------------------------------------------------------------
class SeedInspector:
    """Loads the trained model once; call .predict(image) for repeated inference (used by app.py)."""

    def __init__(self, config_path="config.yaml"):
        self.cfg = load_config(config_path)
        self.device = get_device()
        paths = self.cfg["paths"]

        if not os.path.exists(paths["best_model_path"]):
            raise FileNotFoundError(
                f"[predict] Trained model not found at '{paths['best_model_path']}'. "
                f"Run 'python src/train.py' first, or download a provided checkpoint."
            )
        checkpoint = torch.load(paths["best_model_path"], map_location=self.device)
        self.class_names = checkpoint["class_names"]

        # pretrained=False: a fully trained state_dict is loaded immediately below,
        # so we skip downloading ImageNet weights (no network dependency at inference time).
        self.model = build_model(len(self.class_names), self.cfg, use_pretrained_weights=False)
        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.model.to(self.device)
        self.model.eval()

        self.gradcam = GradCAM(self.model, self.cfg["gradcam"]["target_layer"])
        _, self.eval_tf = build_transforms(self.cfg)
        self.healthy_keyword = self.cfg["quality_score"]["healthy_class_keyword"]

    def predict(self, pil_image: Image.Image):
        pil_image = pil_image.convert("RGB")
        input_tensor = self.eval_tf(pil_image).unsqueeze(0).to(self.device)
        input_tensor.requires_grad_(False)

        # Forward pass for probabilities (no grad needed here)
        with torch.no_grad():
            logits = self.model(input_tensor)
            probs_tensor = F.softmax(logits, dim=1)[0]
        probs = {cls: float(probs_tensor[i]) for i, cls in enumerate(self.class_names)}
        pred_idx = int(torch.argmax(probs_tensor).item())
        predicted_class = self.class_names[pred_idx]
        confidence = probs[predicted_class]

        # Grad-CAM needs gradients -> separate forward+backward pass
        cam, _ = self.gradcam.generate(input_tensor, pred_idx)
        heatmap_overlay = overlay_heatmap(pil_image, cam)

        seed_type, condition = split_standardized_class(predicted_class)
        healthy = is_healthy_class(predicted_class, self.healthy_keyword)
        quality_score = compute_quality_score(probs, predicted_class, self.healthy_keyword)
        recommendation = get_recommendation(condition)

        return {
            "seed_type": seed_type,
            "condition": condition,
            "is_healthy": healthy,
            "predicted_class": predicted_class,
            "confidence": round(confidence * 100, 1),
            "quality_score": quality_score,
            "class_probabilities": {k: round(v * 100, 2) for k, v in probs.items()},
            "gradcam_overlay": heatmap_overlay,
            "recommendation": recommendation,
        }


def main():
    parser = argparse.ArgumentParser(description="Run single-image seed quality inference")
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--image", required=True, help="Path to a seed image file")
    parser.add_argument("--out-heatmap", default=None, help="Optional path to save the Grad-CAM overlay image")
    args = parser.parse_args()

    if not os.path.exists(args.image):
        raise FileNotFoundError(f"[predict] Image not found: '{args.image}'")

    inspector = SeedInspector(args.config)
    result = inspector.predict(Image.open(args.image))

    printable = {k: v for k, v in result.items() if k != "gradcam_overlay"}
    print(json.dumps(printable, indent=2))

    if args.out_heatmap:
        result["gradcam_overlay"].save(args.out_heatmap)
        print(f"[predict] Grad-CAM overlay saved to {args.out_heatmap}")


if __name__ == "__main__":
    main()
