"""
app.py
Gradio web application for the Automated Multi-Seed Quality Assessment system.

Run with:
    python app.py

This loads the trained model once (via SeedInspector) and serves an interactive
UI where a user can upload/drag-drop/capture a seed image and receive:
    Seed Type, Healthy/Defective, Defect Type, Confidence, Quality Score,
    Grad-CAM visual explanation, and an actionable (non-diagnostic) recommendation.
"""

import os
import sys
import traceback

import gradio as gr
from PIL import Image

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))
from utils import load_config
from predict import SeedInspector

CONFIG_PATH = "config.yaml"

DISCLAIMER = (
    "⚠️ **Disclaimer:** This tool provides an AI-based *visual screening* only. "
    "It does NOT replace certified laboratory seed testing (purity, germination, "
    "pathology). Predictions and quality scores are AI-derived visual estimates, "
    "not scientific or medical confirmation of contamination, disease, or viability."
)

# -----------------------------------------------------------------------------
# Load model once at startup. Fail loudly with a clear message if unavailable.
# -----------------------------------------------------------------------------
inspector = None
load_error = None
try:
    inspector = SeedInspector(CONFIG_PATH)
except Exception as e:
    load_error = (
        f"Could not load the trained model: {e}\n\n"
        f"Train a model first with:\n"
        f"    python src/data_prep.py\n"
        f"    python src/train.py\n"
        f"    python src/evaluate.py\n"
        f"Then relaunch this app."
    )
    print("[app.py] WARNING:", load_error)


def analyze_seed(image: Image.Image):
    if image is None:
        return (None, "Please upload a seed image first.", "", "", "", None, {}, "")

    if inspector is None:
        raise gr.Error(load_error or "Model not available.")

    try:
        result = inspector.predict(image)
    except Exception:
        traceback.print_exc()
        raise gr.Error("Prediction failed. See server logs for details.")

    status = "✅ HEALTHY" if result["is_healthy"] else "⚠️ DEFECTIVE"
    defect_display = "None" if result["is_healthy"] else result["condition"].replace("_", " ").title()

    summary_md = f"""
### Seed Type: **{result['seed_type'].title()}**
### Overall Quality: **{status}**
### Predicted Defect: **{defect_display}**
### Confidence: **{result['confidence']}%**
### Quality Score: **{result['quality_score']}/100**

**Recommendation:** {result['recommendation']}

---
{DISCLAIMER}
"""

    probs_sorted = dict(sorted(result["class_probabilities"].items(), key=lambda x: -x[1])[:8])

    return (
        result["gradcam_overlay"],
        summary_md,
        result["seed_type"].title(),
        status,
        defect_display,
        f"{result['confidence']}%",
        probs_sorted,
        f"{result['quality_score']}/100",
    )


CUSTOM_CSS = """
:root {
    --seed-green: #2e7d32;
}
.gradio-container { font-family: 'Segoe UI', system-ui, sans-serif; }
#header-banner {
    background: linear-gradient(90deg, #e8f5e9 0%, #ffffff 100%);
    border-left: 6px solid #2e7d32;
    padding: 16px 20px;
    border-radius: 8px;
    margin-bottom: 10px;
}
footer { visibility: hidden; }
"""

with gr.Blocks(title="Automated Multi-Seed Quality Assessment", css=CUSTOM_CSS,
                theme=gr.themes.Soft(primary_hue="green", neutral_hue="slate")) as demo:

    with gr.Column(elem_id="header-banner"):
        gr.Markdown("# 🌾 Automated Multi-Seed Quality Assessment")
        gr.Markdown(
            "AI-powered screening for seed type identification, quality classification "
            "(Healthy/Defective) and defect detection, with visual (Grad-CAM) explainability."
        )

    with gr.Tabs():
        # ---------------- Seed Analysis tab ----------------
        with gr.Tab("🔍 Seed Analysis"):
            with gr.Row():
                with gr.Column(scale=1):
                    image_input = gr.Image(
                        type="pil", label="Upload Seed Image (drag & drop, file, or camera)",
                        sources=["upload", "webcam", "clipboard"], height=320,
                    )
                    analyze_btn = gr.Button("Analyze Seed", variant="primary")

                with gr.Column(scale=1):
                    heatmap_out = gr.Image(label="AI Attention / Grad-CAM Heatmap", height=320)

            gr.Markdown("## Results")
            result_md = gr.Markdown()

            with gr.Row():
                seed_type_out = gr.Textbox(label="Seed Type", interactive=False)
                quality_out = gr.Textbox(label="Overall Quality", interactive=False)
                defect_out = gr.Textbox(label="Predicted Defect", interactive=False)
            with gr.Row():
                conf_out = gr.Textbox(label="Confidence", interactive=False)
                score_out = gr.Textbox(label="Quality Score", interactive=False)

            gr.Markdown("### Prediction Probabilities (Top classes)")
            probs_out = gr.Label(label="Class Probabilities (%)")

            analyze_btn.click(
                analyze_seed,
                inputs=[image_input],
                outputs=[heatmap_out, result_md, seed_type_out, quality_out,
                         defect_out, conf_out, probs_out, score_out],
            )

        # ---------------- About tab ----------------
        with gr.Tab("ℹ️ About Project"):
            gr.Markdown(f"""
## About This Project

**Automated Multi-Seed Quality Assessment and Defect Classification Using Deep
Learning and Computer Vision** is an academic project demonstrating how
transfer-learning based computer vision (MobileNetV2) can screen agricultural
seed images for visible type and quality condition.

### Pipeline
Image Upload → Validation → Preprocessing → Deep Feature Extraction (MobileNetV2)
→ Seed Type / Quality / Defect Classification → Confidence Scoring →
Grad-CAM Explainability → Quality Score → Recommendation

### Model
- Backbone: MobileNetV2 (ImageNet pretrained, fine-tuned)
- Loss: CrossEntropyLoss | Optimizer: AdamW | Scheduler: Cosine Annealing / ReduceLROnPlateau

### Limitations
- This is a **visual screening tool**, not a certified laboratory test.
- Performance depends entirely on the training dataset's coverage of seed
  varieties, defect types, imaging conditions, and camera quality.
- Does not detect internal/microscopic defects invisible to a standard camera.
- Class list is limited to what public training data made available (see
  `models/label_map.json` / `models/class_names.json` for the exact classes
  this deployed model supports).

{DISCLAIMER}

See the project **README.md** for full methodology, dataset sources, evaluation
metrics, and IEEE-style documentation.
""")

    if load_error:
        gr.Markdown(f"⚠️ **Model not loaded:** {load_error}")

if __name__ == "__main__":
    cfg = load_config(CONFIG_PATH)
    app_cfg = cfg.get("app", {})
    demo.launch(
        server_name=app_cfg.get("server_name", "0.0.0.0"),
        server_port=app_cfg.get("server_port", 7860),
        share=app_cfg.get("share", True),
    )
