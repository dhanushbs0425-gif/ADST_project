# 🌾 Automated Multi-Seed Quality Assessment and Defect Classification Using Deep Learning and Computer Vision

An academic, zero-cost, open-source computer-vision system that screens agricultural
seed images for **seed type**, **quality condition** (healthy/defective) and
**visible defect type**, with confidence scores and Grad-CAM visual explainability,
served through a web application.

> ⚠️ **This project is a visual AI screening tool. It does not replace certified
> laboratory seed testing** (purity, germination, pathology analysis) and does not
> scientifically or medically confirm contamination, disease, or viability from an
> image alone.

---

## Abstract

Manual visual inspection of agricultural seeds is labor-intensive, subjective, and
difficult to scale across large batches, making consistent quality control a
persistent challenge for seed processors, cooperatives, and researchers. This
project applies computer vision and deep learning to automate visual seed
screening. A MobileNetV2 convolutional neural network, initialized with ImageNet
pretrained weights and fine-tuned via transfer learning, classifies seed images by
crop type and visible condition, distinguishing healthy seeds from those exhibiting
documented defects such as breakage, discoloration, mold, or insect damage. The
system reports calibrated confidence scores, an interpretable Grad-CAM heatmap
highlighting the image regions driving each prediction, and a derived 0–100
visual quality score. All components — data pipeline, training, evaluation,
ONNX export, and a Gradio-based web interface — use exclusively free and
open-source tools, making the system reproducible on Google Colab's free GPU tier
without any paid API dependency.

---

## Table of Contents
- [I. Introduction](#i-introduction)
- [II. Literature Review](#ii-literature-review)
- [III. Problem Statement](#iii-problem-statement)
- [IV. Proposed Methodology](#iv-proposed-methodology)
- [V. Dataset and Preprocessing](#v-dataset-and-preprocessing)
- [VI. Model Architecture](#vi-model-architecture)
- [VII. Experimental Setup](#vii-experimental-setup)
- [VIII. Results and Discussion](#viii-results-and-discussion)
- [IX. Web Application](#ix-web-application)
- [X. Conclusion](#x-conclusion)
- [XI. Future Scope](#xi-future-scope)
- [XII. References](#xii-references)
- [Project Structure](#project-structure)
- [Setup & Usage](#setup--usage)
- [Limitations](#limitations)

---

## I. Introduction
Seed quality directly affects germination rate, crop yield, and food security.
Traditional inspection relies on trained personnel visually grading samples — a
process that is slow, inconsistent between inspectors, and hard to audit. Advances
in convolutional neural networks (CNNs) and transfer learning now allow lightweight
models to be trained on modest, freely available datasets and deployed on
commodity hardware, making automated visual screening practical even for
resource-constrained academic and small-scale agricultural settings.

## II. Literature Review
Prior work in agricultural computer vision has applied CNN-based classifiers to
grain and seed sorting tasks, generally reporting that transfer learning from
ImageNet-pretrained backbones (e.g., MobileNet, ResNet, EfficientNet) substantially
reduces the data and compute required versus training from scratch, while
explainability techniques such as Grad-CAM (Selvaraju et al., 2017) have become a
standard way to visually justify CNN predictions in applied/agricultural imaging
contexts. This project follows that established pattern: a lightweight pretrained
backbone (MobileNetV2) fine-tuned on domain-specific seed images, paired with
Grad-CAM for interpretability, rather than proposing a novel architecture.

## III. Problem Statement
Manual seed inspection does not scale to industrial volumes, is subjective across
inspectors, and provides no persistent, auditable record of what was assessed.
An automated, image-based *first-pass screening* system can flag likely-defective
seeds for human/laboratory follow-up faster and more consistently than manual
sampling alone — without claiming to replace certified laboratory testing.

## IV. Proposed Methodology
```
Dataset (public, labeled seed images)
   → Preprocessing (validation, RGB conversion, resize, normalization)
   → Augmentation (rotation, flips, crop, color jitter, affine)
   → Transfer Learning (MobileNetV2, ImageNet weights, replaced classifier head)
   → Training (AdamW, CrossEntropyLoss, cosine/plateau LR schedule, early stopping)
   → Evaluation (held-out test set: accuracy, precision, recall, F1, confusion matrix)
   → Explainability (Grad-CAM heatmaps)
   → Deployment (ONNX export + Gradio web application)
```

## V. Dataset and Preprocessing
**Dataset sources.** This project does not ship or fabricate a dataset. Users must
obtain a legitimate, appropriately licensed public seed-image dataset and place it
under `dataset/raw/<seed_type>/<original_label>/`. Examples of publicly documented
sources (verify current license/terms before use):
- Kaggle wheat / corn / soybean seed quality and defect datasets
- Mendeley Data / Zenodo open agricultural seed image repositories
- University agricultural-extension open-image datasets

**You must record, in this section of your own project write-up, the exact dataset(s)
you used, their source URL, and their license**, since `data_prep.py` is
dataset-agnostic and does not itself pick a dataset for you.

**Label preservation.** Original folder names (dataset labels) are preserved
verbatim (only lower-cased/underscored for filesystem safety) and combined with the
seed type into a standardized class name `<seed_type>__<original_label>`
(see `src/utils.py::standardized_class_name`). No defect category is renamed or
reinterpreted. The full mapping is saved to `models/label_map.json`.

**Cleaning pipeline (`src/data_prep.py`).**
1. Auto-detect `seed_type/label` folder structure under `dataset/raw/`.
2. Open every image to detect and discard corrupted files.
3. Compute a perceptual hash (pHash) per image to detect duplicate and
   near-duplicate images.
4. Group near-duplicates and keep duplicate **groups** intact within a single
   split — this prevents the same physical seed photo (or a lightly-edited copy)
   from appearing in both train and test, avoiding data leakage.
5. Copy cleaned images to `dataset/processed/<standardized_class>/`.
6. Perform an **80/10/10** group-aware split into `dataset/train/`,
   `dataset/validation/`, `dataset/test/`.
7. Write `outputs/dataset_stats.json` with per-class raw/clean/split counts.

**Preprocessing/augmentation (`src/train.py`).** Images are resized to 224×224 and
normalized with ImageNet mean/std. Training-time augmentation (random rotation,
horizontal/vertical flip, random-resized crop, color jitter, small affine) is kept
mild enough to preserve genuine visual defects rather than obscuring or exaggerating
them.

## VI. Model Architecture
```
Input Image (224×224×3)
   → MobileNetV2 (ImageNet-pretrained feature extractor)
   → Global Average Pooling (built into MobileNetV2)
   → Dropout (p configurable, default 0.3)
   → Fully Connected Layer (→ num_classes)
   → Softmax Class Probabilities
```
- **Loss:** CrossEntropyLoss
- **Optimizer:** AdamW
- **LR Scheduler:** CosineAnnealingLR (default) or ReduceLROnPlateau
- **Epochs:** 25 (configurable), with early stopping on validation F1
- **Checkpoint selection:** best validation F1-score

## VII. Experimental Setup
- Hardware: free-tier Google Colab GPU (or CPU fallback; framework auto-detects)
- Framework: PyTorch + torchvision
- Batch size: 32 (configurable in `config.yaml`)
- Train/Val/Test split: 80/10/10, duplicate-group-aware (see Section V)
- Reproducibility: global random seed fixed (`project.seed` in `config.yaml`)

## VIII. Results and Discussion
**No results are hard-coded or fabricated in this repository.** Actual accuracy,
precision, recall, F1-score (macro and weighted), the confusion matrix, and
per-class metrics are generated only after you run:
```
python src/data_prep.py
python src/train.py
python src/evaluate.py
```
which populate `outputs/classification_report.txt`, `outputs/confusion_matrix.png`,
and `outputs/training_curves.png` from your actual dataset and training run. Paste
those generated numbers/plots into this section for your final submission. If class
imbalance is present, review the per-class rows in `classification_report.txt`
specifically — macro F1 will expose weak minority-class performance that overall
accuracy can hide.

## IX. Web Application
The Gradio app (`app.py`) provides:
- Drag-and-drop / file-upload / webcam image input
- Seed Type, Overall Quality (Healthy/Defective), Predicted Defect, Confidence,
  and Quality Score (0–100)
- Grad-CAM heatmap overlay next to the original image
- A ranked bar of class probabilities
- A plain-language, non-diagnostic recommendation
- Persistent screening-tool disclaimer

Launch locally with `python app.py`, or in Colab (see
`Seed_Quality_AI_Colab_Runbook.ipynb`) for a public `*.gradio.live` demo link.

## X. Conclusion
This project demonstrates that a lightweight, transfer-learned CNN (MobileNetV2)
combined with a transparent data pipeline and Grad-CAM explainability can provide
a reproducible, zero-cost, first-pass visual seed screening system. Its value lies
in consistency and speed as a triage aid, not as a replacement for accredited
laboratory seed testing.

## XI. Future Scope
- Real-time camera inspection line integration
- Conveyor-belt automated seed sorting
- Robotic sorting arms driven by model output
- IoT-connected inspection stations
- Edge AI deployment (ONNX Runtime Mobile / TensorRT / quantized models)
- Native mobile application
- Broader seed variety and defect category coverage as more labeled data becomes available
- Multispectral / hyperspectral imaging for defects invisible to RGB cameras
- Automated batch-level quality reporting and traceability logs

## XII. References
1. Sandler, M. et al., "MobileNetV2: Inverted Residuals and Linear Bottlenecks," CVPR 2018.
2. Selvaraju, R. R. et al., "Grad-CAM: Visual Explanations from Deep Networks via Gradient-based Localization," ICCV 2017.
3. Deng, J. et al., "ImageNet: A Large-Scale Hierarchical Image Database," CVPR 2009.
4. Loshchilov, I., Hutter, F., "Decoupled Weight Decay Regularization" (AdamW), ICLR 2019.
5. Paszke, A. et al., "PyTorch: An Imperative Style, High-Performance Deep Learning Library," NeurIPS 2019.
6. Dataset source(s) used for training — *fill in with the exact dataset name, URL, and license you used.*

---

## Project Structure
```
seed-quality-ai/
├── dataset/
│   ├── raw/{wheat,corn,soybean,rice,other}/   <- place downloaded data here
│   ├── processed/
│   ├── train/  validation/  test/
├── models/
│   ├── best_model.pt          (generated by train.py)
│   ├── best_model.onnx        (generated by evaluate.py)
│   ├── class_names.json
│   ├── label_map.json
│   └── config.json
├── outputs/
│   ├── confusion_matrix.png
│   ├── training_curves.png
│   ├── classification_report.txt
│   └── dataset_stats.json
├── src/
│   ├── data_prep.py
│   ├── train.py
│   ├── evaluate.py
│   ├── predict.py
│   └── utils.py
├── app.py
├── requirements.txt
├── config.yaml
├── Seed_Quality_AI_Colab_Runbook.ipynb
├── .gitignore
├── README.md
└── LICENSE
```

## Setup & Usage

### Local
```bash
git clone <your-repo-url> seed-quality-ai
cd seed-quality-ai
python -m venv venv && source venv/bin/activate   # optional but recommended
pip install -r requirements.txt

# 1) Place a public seed dataset under dataset/raw/<seed_type>/<label>/*.jpg
python src/data_prep.py

# 2) Train
python src/train.py

# 3) Evaluate + export ONNX
python src/evaluate.py

# 4) Try a single prediction from the CLI
python src/predict.py --image path/to/seed.jpg --out-heatmap heatmap.png

# 5) Launch the web app
python app.py
```

### Google Colab
Open `Seed_Quality_AI_Colab_Runbook.ipynb` in Colab, enable GPU, and run the
cells top-to-bottom (see notebook for details).

### Testing Instructions
1. **Sanity check the pipeline without a full dataset:** create a tiny synthetic
   folder structure (`dataset/raw/wheat/healthy/`, `dataset/raw/wheat/broken/`)
   with a handful of images each, run `data_prep.py` → `train.py` (few epochs) →
   `evaluate.py` to confirm the full pipeline executes end-to-end and produces
   `outputs/classification_report.txt` and `models/best_model.onnx`.
2. **Verify model/label sync:** `models/class_names.json` must match the class
   folder names under `dataset/train/`; `train.py` and `evaluate.py` both assert
   this and raise a clear error if they diverge.
3. **Verify ONNX correctness:** `evaluate.py` automatically compares PyTorch vs.
   ONNXRuntime outputs on the same input and reports the max absolute difference.
4. **Web app smoke test:** run `python app.py`, upload a sample seed image, and
   confirm Seed Type, Quality, Defect, Confidence, Quality Score, Grad-CAM overlay,
   and Recommendation all render.

## Limitations
- Model quality is entirely dependent on the diversity and labeling accuracy of the
  public dataset(s) supplied by the user — none is bundled with this repository.
- This is an RGB-image visual screening tool; it cannot detect internal, chemical,
  or microbiological seed defects.
- Reported metrics are only as trustworthy as the held-out test set; small datasets
  will produce high-variance estimates — always report per-class metrics, not just
  overall accuracy.
- Grad-CAM highlights *correlated* image regions, not a certified causal
  explanation of the defect.
- Quality Score is a heuristic derived from softmax confidence, not a calibrated
  probability of actual seed viability.
